pyFDS-Evac example: Egress time from an ensemble of seeds
=========================================================

30 agents leave a corridor once per seed; the script reads every exit
time from the trajectories and reports the last exit over the seeds.
Part 2 shows an occupant who is incapacitated by gas and never leaves.
Part 2 needs one small FDS run.

Page: https://pedestriandynamics.org/pyFDS-Evac/docs/using/howto-rset-ensemble/

Run every command from this folder, the folder that holds this
README.txt. The files keep the layout of the pyFDS-Evac repository, so
the commands are the ones on the page, with python instead of uv run
python.

Contents
--------
  README.txt                                    this file
  LICENSE                                       MIT licence of the code
  requirements.txt                              pinned Python packages, from uv.lock
  examples/rset_ensemble.py                     the example script
  run.py                                        the pyFDS-Evac command line
  assets/fic_vs_fed_speed/config.json           JuPedSim scenario of part 1
  assets/fic_vs_fed_speed/geometry.wkt          walkable area of part 1
  assets/fic_vs_fed_speed/fic_vs_fed_speed.fds  FDS deck of the same corridor; part 1 does not run it
  assets/fic_vs_fed_speed/build_geometry.py     writes the part 1 deck, scenario and geometry
  assets/fic_vs_fed_speed/README.md             what the part 1 scenario is
  assets/iso_table22_coupled/iso_table22_a.fds  FDS deck of the gas room (part 2)
  assets/iso_table22_coupled/config_a.json      JuPedSim scenario of the gas room
  assets/iso_table22_coupled/geometry.wkt       walkable area of the gas room
  assets/iso_table22_coupled/README.md          what the gas room is and where it comes from

Versions
--------
The zip was built from this commit. requirements.txt pins every Python
package to the version in its uv.lock.

  pyFDS-Evac   0.2.4, git commit 0cc78aa130f7cf778af1158d83bda865485e5bc8 (2026-10-04)
  Python       >=3.12,<3.15
  jupedsim     1.4.2
  pedpy        1.4.0
  fdsreader    1.11.7
  fdsvismap    0.3.2
  numpy        2.4.4
  shapely      2.1.2
  matplotlib   3.10.8
  pandas       2.3.3
  FDS          FDS-6.10.1-0-g12efa16-release

Run it
------
The commands are for a POSIX shell (Linux, macOS; on Windows, WSL or Git
Bash).

1. Install pyFDS-Evac and the pinned packages:

     python -m venv .venv
     source .venv/bin/activate    # Windows: .venv\Scripts\activate
     pip install -r requirements.txt

2. Run FDS on the gas-room deck for part 2, one process (about 30 s):

     mkdir -p assets/iso_table22_coupled/fds/a
     cp assets/iso_table22_coupled/iso_table22_a.fds assets/iso_table22_coupled/fds/a/
     (cd assets/iso_table22_coupled/fds/a && fds iso_table22_a.fds)

3. Run the example (about 10 s); it also writes the figure into a
   temporary directory and prints its path:

     python examples/rset_ensemble.py

Runtime
-------
  FDS: 30 s wall clock, one process, on an Apple M3 Pro, macOS
  pyFDS-Evac: about 10 s

Expected result
---------------
The page shows these lines. They were produced at commit 449a755d with
Python 3.12.13 on Apple M3 Pro, macOS, from FDS output of
FDS-6.10.1-0-g12efa16-release.

  mean = 44.5 s, SD = 1.8 s
  min-max = 41.5-46.0 s
  95th percentile = 46.0 s
  exit times [], incapacitated 1, remaining 1

python examples/rset_ensemble.py prints these lines among the others the
page shows. The git: line names the commit you run and differs from the
page.

Licence
-------
Code (the .py files): MIT, see LICENSE. FDS decks, scenario files and
geometry: CC-BY-4.0, https://creativecommons.org/licenses/by/4.0/.
Attribution: pyFDS-Evac,
https://github.com/PedestrianDynamics/pyFDS-Evac.

pyFDS-Evac is research software, provided without warranty.
