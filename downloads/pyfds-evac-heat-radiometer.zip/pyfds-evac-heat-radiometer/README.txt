pyFDS-Evac example: Skin radiometer against integrated intensity
================================================================

Three FDS rooms (uniform hot gas, a hot layer, a burner) put skin
radiometers and integrated-intensity devices at the same points. The
scripts read the device output and report where the incident flux q lies
between U/4 and U. No evacuation is run.

Page: https://pedestriandynamics.org/pyFDS-Evac/verification/testing-heat-radiometer/

Run every command from this folder, the folder that holds this
README.txt. The files keep the layout of the pyFDS-Evac repository, so
the commands are the ones on the page, with python instead of uv run
python.

Contents
--------
  README.txt                                          this file
  LICENSE                                             MIT licence of the code
  requirements.txt                                    pinned Python packages, from uv.lock
  assets/heat_radiometer/heat_radiometer_uniform.fds  FDS deck, uniform hot room
  assets/heat_radiometer/heat_radiometer_layer.fds    FDS deck, hot upper layer
  assets/heat_radiometer/heat_radiometer_burner.fds   FDS deck, burner
  scripts/verification/heat_radiometer.py             prints the q/U table of the page
  scripts/verification/heat_radiometer_figures.py     draws the page's figure

Versions
--------
The zip was built from this commit. requirements.txt pins every Python
package to the version in its uv.lock.

  pyFDS-Evac   0.3.1, git commit 71bad0e357e93e0aa663dc402bf00ef9f6c660c8 (2026-10-08)
  Python       >=3.12,<3.15
  jupedsim     1.4.2
  pedpy        1.4.0
  fdsreader    1.11.7
  fdsvismap    0.3.2
  numpy        2.4.4
  shapely      2.1.2
  matplotlib   3.10.8
  pandas       2.3.3
  seaborn      0.13.2
  FDS          FDS-6.10.1-0-g12efa16-release

Run it
------
The commands are for a POSIX shell (Linux, macOS; on Windows, WSL or Git
Bash).

1. Install pyFDS-Evac and the pinned packages:

     python -m venv .venv
     source .venv/bin/activate    # Windows: .venv\Scripts\activate
     pip install -r requirements.txt

2. Run FDS on the three decks, 4 MPI processes each (about 15 s per
   room, 5 min for the burner). DATA is a folder of your choice:

     DATA=$HOME/heat_radiometer
     for C in uniform layer burner; do
       mkdir -p $DATA/$C && cp assets/heat_radiometer/heat_radiometer_$C.fds $DATA/$C/
       (cd $DATA/$C && mpiexec -n 4 fds heat_radiometer_$C.fds)
     done

3. Print the table and draw the figure (a few seconds):

     python scripts/verification/heat_radiometer.py --data $DATA
     python scripts/verification/heat_radiometer_figures.py --data $DATA

Runtime
-------
  FDS: 11 s (uniform), 13 s (layer) and 306 s (burner) wall clock with 4 MPI processes on an Apple M3 Pro, macOS
  pyFDS-Evac: a few seconds; no evacuation is run

Expected result
---------------
The page shows these lines. They were produced at commit 449a755d with
Python 3.12.13 on Apple M3 Pro, macOS, from FDS output of
FDS-6.10.1-0-g12efa16-release.

  | case | z (m) | facing | q/U min / median / max | excess min / median / max |
  | uniform | 1.6 | up | 0.250 / 0.250 / 0.250 | 0.250 / 0.250 / 0.250 |
  | layer | 1.6 | up | 0.404 / 0.416 / 0.417 | 0.438 / 0.450 / 0.451 |
  | burner | 1.6 | px | 0.395 / 0.530 / 0.570 | 0.625 / 0.789 / 0.859 |

scripts/verification/heat_radiometer.py prints a Markdown table with one
row per deck, height and facing: q/U min / median / max, then the same
above ambient. Above are its header and three of its rows. The page's
Result table gives the medians. The page also runs
tests/verification/test_heat_radiometer.py, which needs a clone of the
repository.

Licence
-------
Code (the .py files): MIT, see LICENSE. FDS decks, scenario files and
geometry: CC-BY-4.0, https://creativecommons.org/licenses/by/4.0/.
Attribution: pyFDS-Evac,
https://github.com/PedestrianDynamics/pyFDS-Evac.

pyFDS-Evac is research software, provided without warranty.
